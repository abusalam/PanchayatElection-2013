-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 13, 2013 at 01:15 AM
-- Server version: 5.1.54
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `PE2013_FieldNames`
--

CREATE TABLE IF NOT EXISTS `PE2013_FieldNames` (
  `FieldName` varchar(20) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`FieldName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PE2013_FieldNames`
--


-- --------------------------------------------------------

--
-- Table structure for table `PE2013_Helpline`
--

CREATE TABLE IF NOT EXISTS `PE2013_Helpline` (
  `HelpID` bigint(20) NOT NULL AUTO_INCREMENT,
  `IP` text NOT NULL,
  `AppName` varchar(80) NOT NULL,
  `AppEmail` varchar(50) NOT NULL,
  `SessionID` varchar(32) NOT NULL,
  `TxtQry` longtext NOT NULL,
  `Replied` int(1) NOT NULL DEFAULT '0',
  `ReplyTxt` varchar(300) DEFAULT NULL,
  `QryTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ReplyTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`HelpID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `PE2013_Helpline`
--


-- --------------------------------------------------------

--
-- Table structure for table `PE2013_logs`
--

CREATE TABLE IF NOT EXISTS `PE2013_logs` (
  `LogID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(20) DEFAULT NULL,
  `IP` varchar(15) DEFAULT NULL,
  `Referrer` longtext,
  `UserAgent` longtext,
  `UserID` varchar(20) DEFAULT NULL,
  `URL` longtext,
  `Action` longtext,
  `Method` varchar(10) DEFAULT NULL,
  `URI` longtext,
  `AccessTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`LogID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `PE2013_logs`
--

INSERT INTO `PE2013_logs` (`LogID`, `SessionID`, `IP`, `Referrer`, `UserAgent`, `UserID`, `URL`, `Action`, `Method`, `URI`, `AccessTime`) VALUES
(1, 'b6qeoua2s0ha94g3r3jd', '192.168.89.1', 'http://appflower/PanchayatElection-2013/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/index.php', 'Login: Success', 'POST', '/PanchayatElection-2013/', '2013-03-13 00:02:54'),
(2, 'hn0kkj1fegpukdfe9kdu', '192.168.89.1', 'http://appflower/PanchayatElection-2013/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/index.php', 'Login: Success', 'POST', '/PanchayatElection-2013/', '2013-03-13 00:04:20'),
(3, 'hrnpaqip63v3sm4h9mno', '192.168.89.1', 'http://appflower/PanchayatElection-2013/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/index.php', 'Login: Success', 'POST', '/PanchayatElection-2013/', '2013-03-13 00:04:23'),
(4, 'qk7icmljdpovlglajcoe', '192.168.89.1', 'http://appflower/PanchayatElection-2013/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/index.php', 'Login: Success', 'POST', '/PanchayatElection-2013/', '2013-03-13 00:04:24'),
(5, 'hokq28t78j78cb97st4d', '192.168.89.1', 'http://appflower/PanchayatElection-2013/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/index.php', 'Login: Success', 'POST', '/PanchayatElection-2013/', '2013-03-13 00:04:25'),
(6, 'hl27hhrvsi3fkdn565hr', '192.168.89.1', 'http://appflower/PanchayatElection-2013/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/index.php', 'Login: Success', 'POST', '/PanchayatElection-2013/', '2013-03-13 00:04:26'),
(7, 'seqv125jofa2n7r3m44j', '192.168.89.1', 'http://appflower/PanchayatElection-2013/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/index.php', 'Login: Success', 'POST', '/PanchayatElection-2013/', '2013-03-13 00:04:27'),
(8, '0e229n85bn1qtuvjvuh8', '192.168.89.1', 'http://appflower/PanchayatElection-2013/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/index.php', 'Login: Success', 'POST', '/PanchayatElection-2013/', '2013-03-13 00:07:08'),
(9, 'fcukkcm37rhg7kquch5q', '192.168.89.1', 'http://appflower/PanchayatElection-2013/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/index.php', 'Login: Success', 'POST', '/PanchayatElection-2013/', '2013-03-13 00:08:05'),
(10, '5ac06vurcvsjo1rl23p6', '192.168.89.1', 'http://appflower/PanchayatElection-2013/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/index.php', 'Login: Success', 'POST', '/PanchayatElection-2013/', '2013-03-13 00:08:30'),
(11, '5ac06vurcvsjo1rl23p6', '192.168.89.1', '', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/dataentry.php', 'Process (/PanchayatElection-2013/dataentry.php)', 'GET', '/PanchayatElection-2013/dataentry.php', '2013-03-13 00:11:56'),
(12, '5ac06vurcvsjo1rl23p6', '192.168.89.1', '', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/dataentry.php', 'Process (/PanchayatElection-2013/dataentry.php)', 'GET', '/PanchayatElection-2013/dataentry.php', '2013-03-13 00:12:44'),
(13, '5ac06vurcvsjo1rl23p6', '192.168.89.1', 'http://appflower/PanchayatElection-2013/dataentry.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/dataentry.php', 'Process (/PanchayatElection-2013/dataentry.php)', 'GET', '/PanchayatElection-2013/dataentry.php', '2013-03-13 00:13:22'),
(14, '5ac06vurcvsjo1rl23p6', '192.168.89.1', '', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/dataentry.php', 'Process (/PanchayatElection-2013/dataentry.php)', 'GET', '/PanchayatElection-2013/dataentry.php', '2013-03-13 00:14:38'),
(15, '5ac06vurcvsjo1rl23p6', '192.168.89.1', 'http://appflower/PanchayatElection-2013/dataentry.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22', 'Admin', '/PanchayatElection-2013/dataentry.php', 'Process (/PanchayatElection-2013/dataentry.php)', 'POST', '/PanchayatElection-2013/dataentry.php', '2013-03-13 00:14:43');

-- --------------------------------------------------------

--
-- Table structure for table `PE2013_PartMap`
--

CREATE TABLE IF NOT EXISTS `PE2013_PartMap` (
  `PartID` int(10) NOT NULL AUTO_INCREMENT,
  `PartMapID` int(10) DEFAULT NULL,
  `PartNo` varchar(255) DEFAULT NULL,
  `PartName` varchar(255) DEFAULT NULL,
  `ACNo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`PartID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `PE2013_PartMap`
--


-- --------------------------------------------------------

--
-- Table structure for table `PE2013_Sessions`
--

CREATE TABLE IF NOT EXISTS `PE2013_Sessions` (
  `SessionID` varchar(32) NOT NULL,
  `Token` varchar(32) NOT NULL,
  `AccessTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `HitCount` int(11) NOT NULL,
  `Status` varchar(10) NOT NULL DEFAULT 'Initiated',
  `FingerPrint` varchar(32) NOT NULL,
  PRIMARY KEY (`SessionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PE2013_Sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `PE2013_Users`
--

CREATE TABLE IF NOT EXISTS `PE2013_Users` (
  `UserID` varchar(255) DEFAULT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  `UserPass` varchar(255) DEFAULT NULL,
  `PartMapID` int(10) NOT NULL,
  `Remarks` varchar(255) DEFAULT NULL,
  `LoginCount` int(10) DEFAULT '0',
  `LastLoginTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`PartMapID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PE2013_Users`
--

INSERT INTO `PE2013_Users` (`UserID`, `UserName`, `UserPass`, `PartMapID`, `Remarks`, `LoginCount`, `LastLoginTime`) VALUES
('admin', 'Admin', '68a24878cc568766b735c62be5f306ed', 0, NULL, 281, '2013-03-13 00:08:30'),
('WBAC21901', 'DANTAN-II', '21bdde68f46567ffe01b66fadb2ff4ec', 1, NULL, 363, '2012-12-13 10:21:26'),
('WBAC21902', 'MOHANPUR', '2e2dc15e1fe77a9cff74b9ade2aec7ad', 2, NULL, 147, '2012-12-17 06:16:49'),
('WBAC21903', 'DANTAN-I', 'd326bde3ffdf5720dce7b7a36e92f4b0', 3, NULL, 485, '2012-12-20 10:48:55'),
('WBAC22001', 'GOPIBALLAVPUR-I', '18d45e4db0c2b68a8f0445eab03802fb', 4, NULL, 243, '2012-12-18 11:47:25'),
('WBAC22002', 'GOPIBALLAVPUR-II', '299fb6ea771e5ed0edaaa4a371e211b7', 5, NULL, 291, '2012-12-18 11:48:10'),
('WBAC22003', 'NAYAGRAM', 'aa2d1d7b55d8087807eb44b9c6433b0c', 6, NULL, 487, '2012-12-06 07:34:35'),
('WBAC22101', 'JHARGRAM', '1f772fea77f3e7dd63939dfedbbe0c1a', 7, NULL, 753, '2012-12-18 12:24:38'),
('WBAC22102', 'SANKRAIL', '6f458b55117fbe4a1c0ce726c6e08883', 8, NULL, 222, '2012-12-17 11:19:00'),
('WBAC22201', 'BINPUR-I', '271c56bd6552d6add0a9f3d4093dce78', 9, NULL, 151, '2012-12-10 09:21:16'),
('WBAC22301', 'KESHIARY', 'a8c8580d12110c83d80ec937b049de8b', 10, NULL, 222, '2012-12-31 10:15:02'),
('WBAC22401', 'KHARAGPUR-I', '11a2dfb84cfebdbadeb5b2d00e5d282a', 11, NULL, 872, '2013-03-07 06:17:27'),
('WBAC22501', 'NARAYANGARH', 'ee937986f83744ab7847c6d15ebad733', 12, NULL, 490, '2012-12-14 03:08:31'),
('WBAC22601', 'SABONG', 'db491783b876d320a1ad8e36760532ee', 13, NULL, 1013, '2012-12-28 08:10:41'),
('WBAC22602', 'PINGLA', '6f62b6adb89a2b6ed461caffc037edc7', 14, NULL, 257, '2013-02-21 07:12:36'),
('WBAC22701', 'KHARAGPUR-II', '9b430c2df827a8dd06b4ba2180b0ef7d', 15, NULL, 305, '2013-01-15 11:37:52'),
('WBAC22801', 'MEDINIPUR SADAR', '76f822343d73d4833983d6676eab39d0', 16, NULL, 833, '2013-02-04 09:37:37'),
('WBAC22901', 'DEBRA', '0af64c3ad0455f4873f21700d2eddf02', 17, NULL, 916, '2012-12-07 11:10:51'),
('WBAC23001', 'DASPUR-I', '60ab1383bb36600f4a6583f27bb6ae66', 18, NULL, 253, '2013-01-22 06:21:36'),
('WBAC23002', 'DASPUR-II', '71715b0aebbe05e78bc52fa256ebc09f', 19, NULL, 503, '2012-12-17 06:20:04'),
('WBAC23101', 'GHATAL', '48d572432dff400d3674b744d3807c9d', 20, NULL, 339, '2012-12-10 12:05:32'),
('WBAC23201', 'CHANDRAKONA-I', 'c28add1002bbaa266a74b74ec334676a', 21, NULL, 352, '2012-12-24 09:09:44'),
('WBAC23202', 'CHANDRAKONA-II', '11e56bf4e7daa17b15d326d18fa79082', 22, NULL, 308, '2012-12-07 10:03:58'),
('WBAC23301', 'GARBETA-I', '87804bc38f9048b3cc0625f931f3c177', 23, NULL, 382, '2012-12-17 16:15:24'),
('WBAC23302', 'GARBETA-II', '4ab7d5ab564bc7c4fcea2a902ce66ffa', 24, NULL, 375, '2012-12-27 10:36:49'),
('WBAC23401', 'GARBETA-III', '08e562052fdfa0d8a47af5d62f304155', 25, NULL, 234, '2012-12-27 10:38:31'),
('WBAC23402', 'SALBONI', 'a83ae5750d69a5f573ae3c7a136bd345', 26, NULL, 257, '2012-12-07 06:04:57'),
('WBAC23501', 'KESHPUR', '6cb985a800c41ab22991a33a9ab35cb6', 27, NULL, 588, '2012-12-31 09:51:56'),
('WBAC23701', 'JAMBONI', '0ee1fa18a11d5e38d891809a4c778622', 28, NULL, 319, '2012-12-04 10:29:13'),
('WBAC23702', 'BINPUR-II', 'b005e93926f8963bebed6806d3055af2', 29, NULL, 422, '2012-12-05 11:27:52');

-- --------------------------------------------------------

--
-- Table structure for table `PE2013_Visitors`
--

CREATE TABLE IF NOT EXISTS `PE2013_Visitors` (
  `ip` tinytext,
  `vtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vpage` tinytext,
  `referrer` tinytext,
  `uagent` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PE2013_Visitors`
--

INSERT INTO `PE2013_Visitors` (`ip`, `vtime`, `vpage`, `referrer`, `uagent`) VALUES
('192.168.89.1', '2013-03-13 00:11:56', '/PanchayatElection-2013/dataentry.php', '<>', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22'),
('192.168.89.1', '2013-03-13 00:12:44', '/PanchayatElection-2013/dataentry.php', '<>', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22'),
('192.168.89.1', '2013-03-13 00:13:22', '/PanchayatElection-2013/dataentry.php', '<http://appflower/PanchayatElection-2013/dataentry.php>', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22'),
('192.168.89.1', '2013-03-13 00:14:38', '/PanchayatElection-2013/dataentry.php', '<>', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22'),
('192.168.89.1', '2013-03-13 00:14:43', '/PanchayatElection-2013/dataentry.php', '<http://appflower/PanchayatElection-2013/dataentry.php>', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22');

-- --------------------------------------------------------

--
-- Table structure for table `PE2013_Visits`
--

CREATE TABLE IF NOT EXISTS `PE2013_Visits` (
  `PageID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `PageURL` text NOT NULL,
  `VisitCount` bigint(20) NOT NULL DEFAULT '1',
  `LastVisit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `PageTitle` text,
  `VisitorIP` text NOT NULL,
  PRIMARY KEY (`PageID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `PE2013_Visits`
--

INSERT INTO `PE2013_Visits` (`PageID`, `PageURL`, `VisitCount`, `LastVisit`, `PageTitle`, `VisitorIP`) VALUES
(1, '/PanchayatElection-2013/index.php', 24, '2013-03-13 00:08:40', NULL, '192.168.89.1'),
(2, '/PanchayatElection-2013/dataentry.php', 2, '2013-03-13 00:14:43', NULL, '192.168.89.1');
